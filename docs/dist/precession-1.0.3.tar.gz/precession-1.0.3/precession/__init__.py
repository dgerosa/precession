from .precession import __author__
from .precession import __email__
from .precession import __copyright__
from .precession import __license__
from .precession import __version__
from .precession import __doc__

from .precession import *
