from precession import *
__author__ = precession.__author__
__email__ = precession.__email__
__copyright__ = precession.__copyright__
__license__ = precession.__license__
__version__ = precession.__version__
__doc__ = precession.__doc__
